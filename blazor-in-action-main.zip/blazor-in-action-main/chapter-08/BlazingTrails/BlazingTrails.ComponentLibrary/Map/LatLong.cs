﻿namespace BlazingTrails.ComponentLibrary.Map;

public record LatLong(decimal Lat, decimal Lng);
